<?php

function aaa($a,$abcd=5,$abcd=4) {}
$x=aaa(1,2);
