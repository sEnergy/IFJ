<?php

for($i=0;$i<=10;$i=$i+1){
  for($j=0;$j<=10;$j=$j+1){
    $x=$j*$i;
    $x=put_string($x,"\t");
  }
  $x=put_string("\n");
}
