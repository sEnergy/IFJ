<?php


$x=put_string("ctvrty\n",
boolval(put_string("treti ",
boolval(put_string("druhy ",
boolval(put_string("nulty ","prvni ")-2)) -2)) -2));
