<?php


$x=aaa("1","2","3");

function aaa($abc,$cda,$abc) {
$x=put_string($abc,"\n");
}

