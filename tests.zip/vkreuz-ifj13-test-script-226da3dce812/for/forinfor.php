<?php
for($a=0;$a<10;$a=$a+1){
    for($b=0;$b<10;$b=$b+1){
          for($c=0;$c<10;$c=$c+1){
              for($d=0;$d<10;$d=$d+1){
                $x=put_string($a,$b,$c,$d,", ");
              }
           }
      }
} 
