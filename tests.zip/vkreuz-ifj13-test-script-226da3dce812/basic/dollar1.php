<?php
$x=put_string("$ahoj");
