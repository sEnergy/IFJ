<?php

function  aaa() {}

$x=aaa($aaa @ );
