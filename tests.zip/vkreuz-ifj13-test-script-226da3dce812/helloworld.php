<?php

$x = put_string("Hello world!\n");

return 42;
