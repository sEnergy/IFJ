<?php

$a = 1+(+1-2);
$x=put_string($a);


$b = 1+(1-2+);
$x=put_string($b);
