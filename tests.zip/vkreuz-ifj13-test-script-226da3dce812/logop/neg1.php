<?php

$a = true;
if(!$a) {
	$x=put_string("CHYBA");
}

$x=put_string(!$a);
