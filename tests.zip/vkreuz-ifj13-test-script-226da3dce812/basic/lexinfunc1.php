<?php

function aaa() $1
