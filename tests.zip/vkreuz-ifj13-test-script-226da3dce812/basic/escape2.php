<?php

$x = put_string($a, " \x#28 ", $b, " ", $c, "\n");
