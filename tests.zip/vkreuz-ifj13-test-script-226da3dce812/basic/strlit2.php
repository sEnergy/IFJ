<?php 

$x = "	";
$x= put_string($x);
