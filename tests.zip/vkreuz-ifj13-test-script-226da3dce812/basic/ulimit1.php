<?php
function aaa(){
$str="Naše životy jsou truchlivé jak pláčJednou kvečeru šel z herny mladý hráčvenku sněžilo nad monstrancemi barůvzduch byl vlhký neboť chýlilo se k jaruavšak noc se chvěla jako prériepod údery hvězdné artilériekteré naslouchali u politých stolůpijáci nad sklenicemi alkoholůpolonahé ženy v šatě z pávích permelancholikové jako v podvečerBylo tu však něco těžkého co drtísmutek stesk a úzkost z života i smrtiVracel jsem se domů přes most Legiízpívaje si v duchu malou áriipiják světel nočních bárek na Vltavěz hradčanského dómu bilo dvanáct právěpůlnoc smrti hvězda mého obzoruv této vlahé noci z konce únoruBylo tu však něco těžkého co drtísmutek stesk a úzkost z života i smrtiSkláněje se z mostu uviděl jsem stínsebevrahův stín jenž padal do hlubinbylo tu však něco těžkého co pláčebyl to stín a smutek hazardního hráčeřekl jsem mu probůh pane co jste začodvětil mi smutným hlasem nikdo hráčbylo tu však něco smutného co mlčíbyl to stín jenž jako šibenice trčístín jenž padal z mostu; vykřikl jsem ach!ne vy nejste hráč! ne vy jste sebevrah!Šli jsme oba ruku v ruce oba zachráněníšli jsme ruku v ruce v otevřeném sněníza město kde počínaly Košířez dálky mávaly nám noční vějířenad kiosky smutku tance alkoholůšli jsme ruku v ruce nemluvíce spolubylo tu však něco těžkého co drtísmutek stesk a úzkost z života i smrtiOdemkl jsem dveře rozžal svítiplynveda na nocleh svůj pouliční stínřek jsem pane pro nás pro oba to stačínebylo tu však už stínu po mém hráčiči to byl jen přízrak nebo sebeklam?stál jsem nad svým každodenním lůžkem sámbylo tu však něco těžkého co drtísmutek stesk a úzkost z života i smrtiUsedl jsem za stůl nad kupy svých knihpozoruje oknem padající sníhpozoruje vločky jak své věnce vijíse svou věčně chimérickou nostalgiípiják nezachytitelných odstínůpiják světel potopených do stínůpiják žen jichž poslouchají sny a hadipiják žen jež pochovávají své mládípiják krutých hazardních a krásných ženpiják rozkoše a zkrvavělých pěnpiják všeho krutého co štve a drtípiják hrůz a smutku z života i smrtiŘekl jsem si zapomeň už na stínyotvíraje týden staré novinykde jsem v pachu novinářské černi tonauzřel velkou podobiznu Edisonabyl tu jeho nejnovější vynálezseděl v taláru jak středověký knězbylo tu však něco krásného co drtíodvaha a radost z života i smrti.";


$str=$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . 
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str . $str . $str . $str . $str . $str . $str . $str . $str . $str . $str .
$str;

$x=put_string($str);
}

$x=aaa();
