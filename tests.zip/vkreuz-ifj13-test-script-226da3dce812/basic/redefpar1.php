<?php

function aaa($abcd,$abcd) {}
$x=aaa(1,2,3,4,5);
