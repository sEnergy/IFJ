<?php

function  aaa() {}

$x=aaa(@);
