<?php 

if (""){
  $x=put_string("CHYBA V PROGRAMU\n");
} elseif (0) {
  $x=put_string("CHYBA V PROGRAMU\n");
}

