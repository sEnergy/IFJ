<?php function hello(){} function hello(){}
